interface AssocStringString {
    [key: string]: string;
}

interface GameData {
    name: string;
    lowScore: number;
}