/*Aufgabe: Aufgabe 11
Name: Sarah L�nnqvist
Matrikel: 259116
Datum: 13.01.2019
    
Hiermit versichere ich, dass ich diesen Code selbst geschrieben habe. Er wurde nicht kopiert und auch nicht diktiert.
*/
var Finaly;
(function (Finaly) {
    class Origin {
        draw() { }
        move() { }
    }
    Finaly.Origin = Origin;
})(Finaly || (Finaly = {}));
//# sourceMappingURL=origin.js.map